const scrollToForm = (id) => {
    const links = document.querySelectorAll('a');

    links.forEach((link) => {
        link.onclick = (event) => {
            event.preventDefault();
            document
                .querySelector(id)
                .scrollIntoView({ block: 'center', behavior: 'smooth' });
        };
    });
};

const forms = document.querySelectorAll('form');

forms.forEach((form) => {
    form.onsubmit = (event) => {
        event.preventDefault();

        const button = form.querySelector(
            'button[type=submit], input[type=submit]'
        );

        if (button) button.disabled = true;

        if (getCookie('formSubmited')) {
            return console.log("You've already submitted the form.");
        }

        setCookie('formSubmited', true, 1);

        setTimeout(() => {
            return form.submit();
        }, 300);
    };
});

setCookie(
    'thanksLink',
    window.location.origin +
        window.location.pathname +
        window.location.search +
        '&thanks=true'
);
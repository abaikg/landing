let doors = document.querySelectorAll('.door');
let doorSales = document.querySelectorAll('.door__sales');
let doorWrappers = document.querySelectorAll('.door__wrapper');
let spinResultWrapper = document.querySelector('.spin-result-wrapper');
let orderBlocks = document.querySelectorAll('#order');
let door1 = document.querySelectorAll('#door__1');
let door2 = document.querySelectorAll('#door__2');
let door3 = document.querySelectorAll('#door__3');
let doorSale1 = document.querySelectorAll('#door__sales1');
let doorSale2 = document.querySelectorAll('#door__sales2');
let doorSale3 = document.querySelectorAll('#door__sales3');
let discount = '90%';
doors.forEach(function (door) {
    door.addEventListener('click', openDoor);
});
var closePopup = document.querySelector('.close-popup');
$('.pop-up-button').click(function (a) {
    $('.spin-result-wrapper').fadeOut();
    a.preventDefault();
    $('.spin-result-wrapper').fadeOut();
});
$('.close-popup, .pop-up-button').click(function (a) {
    $('.spin-result-wrapper').fadeOut();
    a.preventDefault();
    $('.spin-result-wrapper').fadeOut();
});

function openDoor(e) {
    e.currentTarget.classList.add('open');
    setTimeout(function () {
        spinResultWrapper.style.display = 'block';
        setTimeout(function () {
            for (let i = 0; i < orderBlocks.length; i++) {
                orderBlocks[i].style.display = 'block';
            }
            for (let i = 0; i < doorWrappers.length; i++) {
                doorWrappers[i].style.display = 'none';
            }
            document.querySelector('.door__head').style.display = 'none';
            start_timer && start_timer();
        }, 3500);
    }, 1500);
    doorSales.forEach(function (sale) {
        if (door1[0].classList.contains('open') || door1[1].classList.contains('open')) {
            doorSale1[0].innerHTML = discount;
            doorSale1[1].innerHTML = discount;
            doorSale2[0].innerHTML = discount === '50%' ? '25%' : '50%';
            doorSale2[1].innerHTML = discount === '50%' ? '25%' : '50%';
            doorSale3[0].innerHTML = discount === '50%' ? '10%' : '25%';
            doorSale3[1].innerHTML = discount === '50%' ? '10%' : '25%';
        } else if (door2[0].classList.contains('open') || door2[1].classList.contains('open')) {
            doorSale2[0].innerHTML = discount;
            doorSale2[1].innerHTML = discount;
            doorSale1[0].innerHTML = discount === '50%' ? '10%' : '25%';
            doorSale1[1].innerHTML = discount === '50%' ? '10%' : '25%';
            doorSale3[0].innerHTML = discount === '50%' ? '25%' : '50%';
            doorSale3[1].innerHTML = discount === '50%' ? '25%' : '50%';
        } else if (door3[0].classList.contains('open') || door3[1].classList.contains('open')) {
            doorSale1[0].innerHTML = discount === '50%' ? '25%' : '50%';
            doorSale1[1].innerHTML = discount === '50%' ? '25%' : '50%';
            doorSale3[0].innerHTML = discount;
            doorSale3[1].innerHTML = discount;
            doorSale2[0].innerHTML = discount === '50%' ? '10%' : '25%';
            doorSale2[1].innerHTML = discount === '50%' ? '10%' : '25%';
        }
    });
    for (let i = 0; i < doors.length; i++) {
        if (!doors[i].classList.contains('open')) {
            setTimeout(function () {
                doors[i].classList.add('open');
            }, 2500);
        }
    }
    for (let j = 0; j < doors.length; j++) {
        doors[j].removeEventListener('click', openDoor);
    }
}

var time = 600;
var intr;

function start_timer() {
    intr = setInterval(tick, 1000);
}

function tick() {
    time = time - 1;
    var mins = Math.floor(time / 60);
    var secs = time - mins * 60;
    if (mins == 0 && secs == 0) {
        clearInterval(intr);
    }
    secs = secs >= 10 ? secs : '0' + secs;
    mins = mins >= 10 ? mins : '0' + mins;
    $('#min').html(mins);
    $('#sec').html(secs);
    $('#min1').html(mins);
    $('#sec1').html(secs);
}